#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{fs, path::PathBuf, process::Command, time::{SystemTime, UNIX_EPOCH}};
use tao::{
    dpi::LogicalSize as WinSize,
    event::{Event, WindowEvent},
    event_loop::{ControlFlow, EventLoopBuilder, EventLoopProxy},
    window::{Window, WindowBuilder},
};
use wry::{
    dpi::{LogicalPosition, LogicalSize},
    Rect, WebContext, WebView, WebViewBuilder,
};

const APP: &str = "AIBrowser";
const HOME: &str = "https://www.google.com";
const TOOLBAR_H: f64 = 88.0; // tab strip (38) + nav bar (50)

// ───────────────────────── Events ─────────────────────────

#[derive(Debug)]
enum UserEvent {
    Ui(String),
    TabTitle(u32, String),
    TabUrl(u32, String),
    NewTab(String),
    DlStart(String, String),
    DlDone(String, bool),
}

// ───────────────────────── Profiles ─────────────────────────

#[derive(Serialize, Deserialize, Clone)]
struct Profile {
    id: String,
    name: String,
    color: String,
}

fn base_dir() -> PathBuf {
    let root = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir);
    root.join(APP)
}
fn profiles_file() -> PathBuf {
    base_dir().join("profiles.json")
}
fn profile_dir(id: &str) -> PathBuf {
    base_dir().join("profiles").join(id)
}
fn load_profiles() -> Vec<Profile> {
    fs::read_to_string(profiles_file())
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}
fn save_profiles(p: &[Profile]) {
    let _ = fs::create_dir_all(base_dir());
    let _ = fs::write(profiles_file(), serde_json::to_string_pretty(p).unwrap());
}
fn millis() -> u128 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis()).unwrap_or(0)
}
fn spawn_self(args: &[&str]) {
    if let Ok(exe) = std::env::current_exe() {
        let _ = Command::new(exe).args(args).spawn();
    }
}

// ───────────────────────── URL helpers ─────────────────────────

fn urlenc(s: &str) -> String {
    let mut o = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => o.push(b as char),
            b' ' => o.push('+'),
            _ => o.push_str(&format!("%{:02X}", b)),
        }
    }
    o
}

/// Link -> open site. Normal text -> Google public search.
fn normalize(input: &str) -> String {
    let s = input.trim();
    if s.is_empty() {
        return HOME.to_string();
    }
    if s.starts_with("http://") || s.starts_with("https://") || s.starts_with("file://") {
        return s.to_string();
    }
    if !s.contains(' ') && (s.contains('.') || s.starts_with("localhost")) {
        return format!("https://{}", s);
    }
    format!("https://www.google.com/search?q={}", urlenc(s))
}

fn rect(x: f64, y: f64, w: f64, h: f64) -> Rect {
    Rect {
        position: LogicalPosition::new(x, y).into(),
        size: LogicalSize::new(w.max(1.0), h.max(1.0)).into(),
    }
}

// ───────────────────────── main ─────────────────────────

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut profile_id: Option<String> = None;
    let mut temp = false;
    let mut start: Option<String> = None;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--profile" => {
                profile_id = args.get(i + 1).cloned();
                i += 1;
            }
            "--temp" => {
                temp = true;
                if let Some(u) = args.get(i + 1) {
                    if !u.starts_with("--") {
                        start = Some(u.clone());
                        i += 1;
                    }
                }
            }
            _ => {}
        }
        i += 1;
    }

    if temp {
        run_browser(None, true, start);
    } else if let Some(id) = profile_id {
        match load_profiles().into_iter().find(|p| p.id == id) {
            Some(p) => run_browser(Some(p), false, None),
            None => run_picker(),
        }
    } else {
        run_picker();
    }
}

// ───────────────────────── Profile picker ─────────────────────────

fn run_picker() {
    let el = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy = el.create_proxy();
    let window = WindowBuilder::new()
        .with_title(APP)
        .with_inner_size(WinSize::new(1000.0, 700.0))
        .build(&el)
        .unwrap();

    let ui_dir = base_dir().join("ui");
    let _ = fs::create_dir_all(&ui_dir);
    let mut ctx = WebContext::new(Some(ui_dir));

    let webview = WebViewBuilder::new_with_web_context(&mut ctx)
        .with_html(include_str!("../ui/picker.html"))
        .with_ipc_handler(move |req| {
            let _ = proxy.send_event(UserEvent::Ui(req.body().to_string()));
        })
        .build(&window)
        .unwrap();

    el.run(move |event, _, flow| {
        let _keep = (&window, &ctx);
        *flow = ControlFlow::Wait;
        match event {
            Event::WindowEvent { event: WindowEvent::CloseRequested, .. } => *flow = ControlFlow::Exit,
            Event::UserEvent(UserEvent::Ui(msg)) => {
                let v: Value = serde_json::from_str(&msg).unwrap_or(Value::Null);
                let mut profiles = load_profiles();
                match v["cmd"].as_str().unwrap_or("") {
                    "create" => {
                        let name = v["name"].as_str().unwrap_or("").trim().to_string();
                        let color = v["color"].as_str().unwrap_or("#4f8cff").to_string();
                        profiles.push(Profile {
                            id: format!("p{}", millis()),
                            name: if name.is_empty() { "Profile".into() } else { name },
                            color,
                        });
                        save_profiles(&profiles);
                    }
                    "delete" => {
                        if let Some(id) = v["id"].as_str() {
                            if profiles.iter().any(|p| p.id == id) {
                                profiles.retain(|p| p.id != id);
                                let _ = fs::remove_dir_all(profile_dir(id));
                                save_profiles(&profiles);
                            }
                        }
                    }
                    "open" => {
                        if let Some(id) = v["id"].as_str() {
                            if profiles.iter().any(|p| p.id == id) {
                                spawn_self(&["--profile", id]);
                                *flow = ControlFlow::Exit;
                                return;
                            }
                        }
                    }
                    "temp" => {
                        let url = normalize(v["url"].as_str().unwrap_or(""));
                        spawn_self(&["--temp", &url]);
                        *flow = ControlFlow::Exit;
                        return;
                    }
                    _ => {}
                }
                let _ = webview.evaluate_script(&format!(
                    "setProfiles({})",
                    serde_json::to_string(&profiles).unwrap()
                ));
            }
            _ => {}
        }
    });
}

// ───────────────────────── Browser window ─────────────────────────

struct Tab {
    id: u32,
    title: String,
    url: String,
    view: WebView,
}

struct Dl {
    key: String,
    name: String,
    state: u8, // 0 running, 1 done, 2 failed
}

struct Browser {
    window: Window,
    ctx: WebContext,
    proxy: EventLoopProxy<UserEvent>,
    toolbar: WebView,
    tabs: Vec<Tab>,
    active: u32,
    next_id: u32,
    overlay: bool,
    downloads: Vec<Dl>,
    profile_name: String,
    temp: bool,
}

impl Browser {
    fn size(&self) -> (f64, f64) {
        let s = self.window.inner_size().to_logical::<f64>(self.window.scale_factor());
        (s.width, s.height)
    }

    fn layout(&self) {
        let (w, h) = self.size();
        let th = if self.overlay { h } else { TOOLBAR_H };
        let _ = self.toolbar.set_bounds(rect(0.0, 0.0, w, th));
        for t in &self.tabs {
            let _ = t.view.set_bounds(rect(0.0, TOOLBAR_H, w, h - TOOLBAR_H));
        }
    }

    fn show_active(&self) {
        for t in &self.tabs {
            let _ = t.view.set_visible(t.id == self.active && !self.overlay);
        }
    }

    fn open_tab(&mut self, url: &str) {
        let id = self.next_id;
        self.next_id += 1;
        let (w, h) = self.size();
        let (p1, p2, p3, p4, p5, p6) = (
            self.proxy.clone(), self.proxy.clone(), self.proxy.clone(),
            self.proxy.clone(), self.proxy.clone(), self.proxy.clone(),
        );
        let incognito = self.temp;

        let view = WebViewBuilder::new_with_web_context(&mut self.ctx)
            .with_url(url)
            .with_bounds(rect(0.0, TOOLBAR_H, w, h - TOOLBAR_H))
            .with_incognito(incognito)
            .with_document_title_changed_handler(move |t| {
                let _ = p1.send_event(UserEvent::TabTitle(id, t));
            })
            .with_navigation_handler(move |u| {
                let _ = p2.send_event(UserEvent::TabUrl(id, u));
                true
            })
            .with_on_page_load_handler(move |_ev, u| {
                let _ = p3.send_event(UserEvent::TabUrl(id, u));
            })
            .with_new_window_req_handler(move |u| {
                let _ = p4.send_event(UserEvent::NewTab(u));
                false
            })
            .with_download_started_handler(move |url, path| {
                let name = path
                    .file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_else(|| "file".into());
                let _ = p5.send_event(UserEvent::DlStart(url, name));
                true
            })
            .with_download_completed_handler(move |url, _path, ok| {
                let _ = p6.send_event(UserEvent::DlDone(url, ok));
            })
            .build_as_child(&self.window)
            .unwrap();

        self.tabs.push(Tab { id, title: String::new(), url: url.to_string(), view });
        self.active = id;
        self.overlay = false;
        self.layout();
        self.show_active();
    }

    fn close_tab(&mut self, id: u32) -> bool {
        if let Some(pos) = self.tabs.iter().position(|t| t.id == id) {
            self.tabs.remove(pos);
            if self.active == id {
                if let Some(t) = self.tabs.get(pos.min(self.tabs.len().saturating_sub(1))) {
                    self.active = t.id;
                }
            }
        }
        self.show_active();
        !self.tabs.is_empty()
    }

    fn active_view(&self) -> Option<&WebView> {
        self.tabs.iter().find(|t| t.id == self.active).map(|t| &t.view)
    }

    fn push(&self) {
        let tabs: Vec<Value> = self
            .tabs
            .iter()
            .map(|t| json!({"id": t.id, "title": t.title, "url": t.url}))
            .collect();
        let dls: Vec<Value> = self
            .downloads
            .iter()
            .rev()
            .map(|d| json!({"name": d.name, "state": d.state}))
            .collect();
        let st = json!({
            "tabs": tabs, "active": self.active, "downloads": dls,
            "profile": self.profile_name, "temp": self.temp
        });
        let _ = self.toolbar.evaluate_script(&format!("setState({})", st));
    }

    /// returns true when the app should exit
    fn on_event(&mut self, ev: UserEvent) -> bool {
        match ev {
            UserEvent::Ui(msg) => {
                let v: Value = serde_json::from_str(&msg).unwrap_or(Value::Null);
                match v["cmd"].as_str().unwrap_or("") {
                    "nav" => {
                        let u = normalize(v["url"].as_str().unwrap_or(""));
                        if let Some(view) = self.active_view() {
                            let _ = view.load_url(&u);
                        }
                    }
                    "back" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("history.back()"); }
                    }
                    "forward" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("history.forward()"); }
                    }
                    "reload" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("location.reload()"); }
                    }
                    "home" => {
                        if let Some(view) = self.active_view() { let _ = view.load_url(HOME); }
                    }
                    "newtab" => self.open_tab(HOME),
                    "close" => {
                        if let Some(id) = v["id"].as_u64() {
                            if !self.close_tab(id as u32) {
                                return true;
                            }
                        }
                    }
                    "switch" => {
                        if let Some(id) = v["id"].as_u64() {
                            self.active = id as u32;
                            self.show_active();
                        }
                    }
                    "overlay" => {
                        self.overlay = v["on"].as_bool().unwrap_or(false);
                        self.layout();
                        self.show_active();
                    }
                    "temp" => {
                        let u = normalize(v["url"].as_str().unwrap_or(""));
                        spawn_self(&["--temp", &u]);
                    }
                    "profiles" => spawn_self(&[]),
                    _ => {}
                }
                self.push();
            }
            UserEvent::TabTitle(id, t) => {
                if let Some(tab) = self.tabs.iter_mut().find(|x| x.id == id) {
                    tab.title = t.clone();
                }
                if id == self.active {
                    self.window.set_title(&format!("{} - {}", t, APP));
                }
                self.push();
            }
            UserEvent::TabUrl(id, u) => {
                if let Some(tab) = self.tabs.iter_mut().find(|x| x.id == id) {
                    tab.url = u;
                }
                self.push();
            }
            UserEvent::NewTab(u) => {
                self.open_tab(&u);
                self.push();
            }
            UserEvent::DlStart(key, name) => {
                self.downloads.push(Dl { key, name, state: 0 });
                self.push();
            }
            UserEvent::DlDone(key, ok) => {
                if let Some(d) = self.downloads.iter_mut().rev().find(|d| d.key == key && d.state == 0) {
                    d.state = if ok { 1 } else { 2 };
                }
                self.push();
            }
        }
        false
    }
}

fn run_browser(profile: Option<Profile>, temp: bool, start: Option<String>) {
    let el = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy = el.create_proxy();

    let profile_name = if temp {
        "Temp session".to_string()
    } else {
        profile.as_ref().map(|p| p.name.clone()).unwrap_or_default()
    };

    let window = WindowBuilder::new()
        .with_title(format!("{} - {}", profile_name, APP))
        .with_inner_size(WinSize::new(1280.0, 800.0))
        .with_min_inner_size(WinSize::new(640.0, 420.0))
        .build(&el)
        .unwrap();

    // Each profile has its own WebView2 data folder = separate cookies/logins/cache.
    let data_dir = if temp {
        std::env::temp_dir().join(format!("{}-temp-{}", APP, std::process::id()))
    } else {
        profile_dir(&profile.as_ref().unwrap().id)
    };
    let _ = fs::create_dir_all(&data_dir);
    let mut ctx = WebContext::new(Some(data_dir));

    let size = window.inner_size().to_logical::<f64>(window.scale_factor());
    let ui_proxy = proxy.clone();
    let toolbar = WebViewBuilder::new_with_web_context(&mut ctx)
        .with_html(include_str!("../ui/browser.html"))
        .with_bounds(rect(0.0, 0.0, size.width, TOOLBAR_H))
        .with_ipc_handler(move |req| {
            let _ = ui_proxy.send_event(UserEvent::Ui(req.body().to_string()));
        })
        .build_as_child(&window)
        .unwrap();

    let mut b = Browser {
        window,
        ctx,
        proxy,
        toolbar,
        tabs: Vec::new(),
        active: 0,
        next_id: 1,
        overlay: false,
        downloads: Vec::new(),
        profile_name,
        temp,
    };
    b.open_tab(&start.unwrap_or_else(|| HOME.to_string()));
    b.push();

    el.run(move |event, _, flow| {
        *flow = ControlFlow::Wait;
        match event {
            Event::WindowEvent { event, .. } => match event {
                WindowEvent::CloseRequested => *flow = ControlFlow::Exit,
                WindowEvent::Resized(_) => b.layout(),
                _ => {}
            },
            Event::UserEvent(ev) => {
                if b.on_event(ev) {
                    *flow = ControlFlow::Exit;
                }
            }
            _ => {}
        }
    });
}
