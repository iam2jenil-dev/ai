# Falcon

Fast, private, profile-based browser (Rust + WebView2).

## Build
1. Install Rust (https://rustup.rs) and, for the installer, Inno Setup 6.
2. Double-click `build.bat`  ->  `dist\Falcon-Setup-1.0.0.exe`
   (without Inno Setup you still get `target\release\falcon.exe`).

## Install / Uninstall
Run the setup exe. Uninstall from **Settings > Apps > Falcon** (or Start menu).
The uninstaller asks whether to also delete profiles, quick links and browsing data
(`%APPDATA%\Falcon`).

## Quick links
Open a profile -> start page -> **Add link**. Links are stored per profile and show up
every time that profile opens. Hover a tile to edit or remove it.

## Icon
`assets/falcon.svg` is the master logo. `assets/falcon.ico` / `icon.rgba` are generated from it.
