@echo off
setlocal
cd /d "%~dp0"
echo.
echo  [1/2] Building Falcon (release)...
cargo build --release || goto :err

echo.
echo  [2/2] Creating installer...
where iscc >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
    "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" installer\falcon.iss || goto :err
  ) else (
    echo  Inno Setup 6 not found. Install it from https://jrsoftware.org/isdl.php
    echo  Falcon.exe is ready at target\release\falcon.exe
    goto :end
  )
) else (
  iscc installer\falcon.iss || goto :err
)
echo.
echo  Done!  Installer: dist\Falcon-Setup-1.0.0.exe
goto :end
:err
echo.
echo  Build failed.
exit /b 1
:end
endlocal
