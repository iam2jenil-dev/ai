// Embeds the Falcon icon + version info into falcon.exe (Windows only).
fn main() {
    println!("cargo:rerun-if-changed=assets/falcon.ico");
    #[cfg(windows)]
    {
        let mut res = winresource::WindowsResource::new();
        res.set_icon("assets/falcon.ico");
        res.set("ProductName", "Falcon");
        res.set("FileDescription", "Falcon Browser");
        res.set("CompanyName", "Falcon");
        res.set("LegalCopyright", "Copyright (c) Falcon");
        if let Err(e) = res.compile() {
            println!("cargo:warning=could not embed icon: {e}");
        }
    }
}
