#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{fs, path::PathBuf, process::Command, time::{SystemTime, UNIX_EPOCH}};
use tao::{
    dpi::LogicalSize as WinSize,
    event::{Event, WindowEvent},
    event_loop::{ControlFlow, EventLoopBuilder, EventLoopProxy},
    window::{Icon, Theme, Window, WindowBuilder},
};
use wry::{
    dpi::{LogicalPosition, LogicalSize},
    Rect, WebContext, WebView, WebViewBuilder,
};

const APP: &str = "Falcon";
const VERSION: &str = env!("CARGO_PKG_VERSION");
const HOME: &str = "https://www.google.com";
const TOOLBAR_H: f64 = 92.0; // tab strip (40) + nav bar (52)
const MAX_LINKS: usize = 24;
const BLACK: (u8, u8, u8, u8) = (0, 0, 0, 255);

// ───────────────────────── Events ─────────────────────────

#[derive(Debug)]
enum UserEvent {
    Ui(String),
    TabTitle(u32, String),
    TabUrl(u32, String),
    NewTab(String),
    DlStart(String, String),
    DlDone(String, bool),
}

// ───────────────────────── Profiles ─────────────────────────

#[derive(Serialize, Deserialize, Clone)]
struct Link {
    title: String,
    url: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct Profile {
    id: String,
    name: String,
    color: String,
    #[serde(default)]
    links: Vec<Link>,
}

fn base_dir() -> PathBuf {
    let root = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir);
    root.join(APP)
}
fn profiles_file() -> PathBuf {
    base_dir().join("profiles.json")
}
fn profile_dir(id: &str) -> PathBuf {
    base_dir().join("profiles").join(id)
}
fn load_profiles() -> Vec<Profile> {
    fs::read_to_string(profiles_file())
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}
fn save_profiles(p: &[Profile]) {
    let _ = fs::create_dir_all(base_dir());
    let _ = fs::write(profiles_file(), serde_json::to_string_pretty(p).unwrap());
}
fn millis() -> u128 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis()).unwrap_or(0)
}
fn spawn_self(args: &[&str]) {
    if let Ok(exe) = std::env::current_exe() {
        let _ = Command::new(exe).args(args).spawn();
    }
}

/// Old builds were called "AIBrowser". Keep the user's profiles when upgrading.
fn migrate_legacy() {
    if let Some(root) = std::env::var_os("APPDATA").map(PathBuf::from) {
        let old = root.join("AIBrowser");
        let new = root.join(APP);
        if old.exists() && !new.exists() {
            let _ = fs::rename(old, new);
        }
    }
}

fn window_icon() -> Option<Icon> {
    Icon::from_rgba(include_bytes!("../assets/icon.rgba").to_vec(), 64, 64).ok()
}

// ───────────────────────── URL helpers ─────────────────────────

fn urlenc(s: &str) -> String {
    let mut o = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => o.push(b as char),
            b' ' => o.push('+'),
            _ => o.push_str(&format!("%{:02X}", b)),
        }
    }
    o
}

/// Link -> open site. Normal text -> Google public search.
fn normalize(input: &str) -> String {
    let s = input.trim();
    if s.is_empty() {
        return HOME.to_string();
    }
    if s.starts_with("http://") || s.starts_with("https://") || s.starts_with("file://") {
        return s.to_string();
    }
    if !s.contains(' ') && (s.contains('.') || s.starts_with("localhost")) {
        return format!("https://{}", s);
    }
    format!("https://www.google.com/search?q={}", urlenc(s))
}

/// Validates a saved shortcut. Only http(s) links are stored.
fn clean_link(input: &str) -> Option<String> {
    let s = input.trim();
    if s.is_empty() || s.contains(' ') {
        return None;
    }
    if s.starts_with("http://") || s.starts_with("https://") {
        return Some(s.to_string());
    }
    if s.contains("://") {
        return None;
    }
    Some(format!("https://{}", s))
}

fn host_of(url: &str) -> String {
    let s = url.split("://").nth(1).unwrap_or(url);
    let h = s.split('/').next().unwrap_or(s);
    h.trim_start_matches("www.").to_string()
}

fn link_title(title: &str, url: &str) -> String {
    let t = title.trim();
    let t = if t.is_empty() { host_of(url) } else { t.to_string() };
    t.chars().take(40).collect()
}

fn rect(x: f64, y: f64, w: f64, h: f64) -> Rect {
    Rect {
        position: LogicalPosition::new(x, y).into(),
        size: LogicalSize::new(w.max(1.0), h.max(1.0)).into(),
    }
}

// ───────────────────────── main ─────────────────────────

fn main() {
    migrate_legacy();

    let args: Vec<String> = std::env::args().collect();
    let mut profile_id: Option<String> = None;
    let mut temp = false;
    let mut start: Option<String> = None;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--profile" => {
                profile_id = args.get(i + 1).cloned();
                i += 1;
            }
            "--temp" => {
                temp = true;
                if let Some(u) = args.get(i + 1) {
                    if !u.starts_with("--") {
                        start = Some(u.clone());
                        i += 1;
                    }
                }
            }
            _ => {}
        }
        i += 1;
    }

    if temp {
        run_browser(None, true, start);
    } else if let Some(id) = profile_id {
        match load_profiles().into_iter().find(|p| p.id == id) {
            Some(p) => run_browser(Some(p), false, None),
            None => run_picker(),
        }
    } else {
        run_picker();
    }
}

// ───────────────────────── Profile picker ─────────────────────────

fn run_picker() {
    let el = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy = el.create_proxy();
    let window = WindowBuilder::new()
        .with_title(APP)
        .with_inner_size(WinSize::new(1000.0, 700.0))
        .with_min_inner_size(WinSize::new(640.0, 480.0))
        .with_window_icon(window_icon())
        .with_theme(Some(Theme::Dark))
        .build(&el)
        .unwrap();

    let ui_dir = base_dir().join("ui");
    let _ = fs::create_dir_all(&ui_dir);
    let mut ctx = WebContext::new(Some(ui_dir));

    let webview = WebViewBuilder::new_with_web_context(&mut ctx)
        .with_html(include_str!("../ui/picker.html"))
        .with_background_color(BLACK)
        .with_ipc_handler(move |req| {
            let _ = proxy.send_event(UserEvent::Ui(req.body().to_string()));
        })
        .build(&window)
        .unwrap();

    el.run(move |event, _, flow| {
        let _keep = (&window, &ctx);
        *flow = ControlFlow::Wait;
        match event {
            Event::WindowEvent { event: WindowEvent::CloseRequested, .. } => *flow = ControlFlow::Exit,
            Event::UserEvent(UserEvent::Ui(msg)) => {
                let v: Value = serde_json::from_str(&msg).unwrap_or(Value::Null);
                let mut profiles = load_profiles();
                match v["cmd"].as_str().unwrap_or("") {
                    "create" => {
                        let name = v["name"].as_str().unwrap_or("").trim().to_string();
                        let color = v["color"].as_str().unwrap_or("#ffffff").to_string();
                        profiles.push(Profile {
                            id: format!("p{}", millis()),
                            name: if name.is_empty() { "Profile".into() } else { name },
                            color,
                            links: vec![],
                        });
                        save_profiles(&profiles);
                    }
                    "delete" => {
                        if let Some(id) = v["id"].as_str() {
                            if profiles.iter().any(|p| p.id == id) {
                                profiles.retain(|p| p.id != id);
                                let _ = fs::remove_dir_all(profile_dir(id));
                                save_profiles(&profiles);
                            }
                        }
                    }
                    "open" => {
                        if let Some(id) = v["id"].as_str() {
                            if profiles.iter().any(|p| p.id == id) {
                                spawn_self(&["--profile", id]);
                                *flow = ControlFlow::Exit;
                                return;
                            }
                        }
                    }
                    "temp" => {
                        let url = normalize(v["url"].as_str().unwrap_or(""));
                        spawn_self(&["--temp", &url]);
                        *flow = ControlFlow::Exit;
                        return;
                    }
                    _ => {}
                }
                let _ = webview.evaluate_script(&format!(
                    "setProfiles({})",
                    serde_json::to_string(&profiles).unwrap()
                ));
            }
            _ => {}
        }
    });
}

// ───────────────────────── Browser window ─────────────────────────

struct Tab {
    id: u32,
    title: String,
    url: String,
    /// `None` = Falcon start page (rendered by the toolbar view, no web content yet).
    view: Option<WebView>,
}

struct Dl {
    key: String,
    name: String,
    state: u8, // 0 running, 1 done, 2 failed
}

struct Browser {
    window: Window,
    ctx: WebContext,
    proxy: EventLoopProxy<UserEvent>,
    toolbar: WebView,
    tabs: Vec<Tab>,
    active: u32,
    next_id: u32,
    panel: bool,
    downloads: Vec<Dl>,
    profile_name: String,
    profile: Option<Profile>,
    temp: bool,
}

impl Browser {
    fn size(&self) -> (f64, f64) {
        let s = self.window.inner_size().to_logical::<f64>(self.window.scale_factor());
        (s.width, s.height)
    }

    fn is_start_active(&self) -> bool {
        self.tabs
            .iter()
            .find(|t| t.id == self.active)
            .map(|t| t.view.is_none())
            .unwrap_or(false)
    }

    /// The toolbar view grows to full height when a menu panel is open
    /// or when the Falcon start page is showing.
    fn layout(&self) {
        let (w, h) = self.size();
        let full = self.panel || self.is_start_active();
        let th = if full { h } else { TOOLBAR_H };
        let _ = self.toolbar.set_bounds(rect(0.0, 0.0, w, th));
        for t in &self.tabs {
            if let Some(v) = &t.view {
                let _ = v.set_bounds(rect(0.0, TOOLBAR_H, w, h - TOOLBAR_H));
            }
        }
    }

    fn show_active(&self) {
        for t in &self.tabs {
            if let Some(v) = &t.view {
                let _ = v.set_visible(t.id == self.active && !self.panel);
            }
        }
    }

    fn build_view(&mut self, id: u32, url: &str) -> WebView {
        let (w, h) = self.size();
        let (p1, p2, p3, p4, p5, p6) = (
            self.proxy.clone(), self.proxy.clone(), self.proxy.clone(),
            self.proxy.clone(), self.proxy.clone(), self.proxy.clone(),
        );
        let incognito = self.temp;

        WebViewBuilder::new_with_web_context(&mut self.ctx)
            .with_url(url)
            .with_bounds(rect(0.0, TOOLBAR_H, w, h - TOOLBAR_H))
            .with_incognito(incognito)
            .with_document_title_changed_handler(move |t| {
                let _ = p1.send_event(UserEvent::TabTitle(id, t));
            })
            .with_navigation_handler(move |u| {
                let _ = p2.send_event(UserEvent::TabUrl(id, u));
                true
            })
            .with_on_page_load_handler(move |_ev, u| {
                let _ = p3.send_event(UserEvent::TabUrl(id, u));
            })
            .with_new_window_req_handler(move |u| {
                let _ = p4.send_event(UserEvent::NewTab(u));
                false
            })
            .with_download_started_handler(move |url, path| {
                let name = path
                    .file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_else(|| "file".into());
                let _ = p5.send_event(UserEvent::DlStart(url, name));
                true
            })
            .with_download_completed_handler(move |url, _path, ok| {
                let _ = p6.send_event(UserEvent::DlDone(url, ok));
            })
            .build_as_child(&self.window)
            .unwrap()
    }

    /// `None` opens the Falcon start page, `Some(url)` opens a website.
    fn open_tab(&mut self, url: Option<&str>) {
        let id = self.next_id;
        self.next_id += 1;
        let view = url.map(|u| self.build_view(id, u));
        self.tabs.push(Tab {
            id,
            title: String::new(),
            url: url.unwrap_or("").to_string(),
            view,
        });
        self.active = id;
        self.panel = false;
        self.layout();
        self.show_active();
    }

    /// Loads a URL in the active tab. A start-page tab turns into a web tab.
    fn navigate(&mut self, url: &str) {
        let id = self.active;
        let idx = match self.tabs.iter().position(|t| t.id == id) {
            Some(i) => i,
            None => return,
        };
        if let Some(v) = &self.tabs[idx].view {
            let _ = v.load_url(url);
        } else {
            let view = self.build_view(id, url);
            self.tabs[idx].view = Some(view);
            self.tabs[idx].url = url.to_string();
            self.layout();
            self.show_active();
        }
    }

    fn close_tab(&mut self, id: u32) -> bool {
        if let Some(pos) = self.tabs.iter().position(|t| t.id == id) {
            self.tabs.remove(pos);
            if self.active == id {
                if let Some(t) = self.tabs.get(pos.min(self.tabs.len().saturating_sub(1))) {
                    self.active = t.id;
                }
            }
        }
        self.layout();
        self.show_active();
        !self.tabs.is_empty()
    }

    fn active_view(&self) -> Option<&WebView> {
        self.tabs
            .iter()
            .find(|t| t.id == self.active)
            .and_then(|t| t.view.as_ref())
    }

    /// Edits this profile's quick links and saves them to profiles.json.
    fn update_links(&mut self, f: impl FnOnce(&mut Vec<Link>)) {
        if let Some(p) = self.profile.as_mut() {
            f(&mut p.links);
            let mut all = load_profiles();
            if let Some(x) = all.iter_mut().find(|x| x.id == p.id) {
                x.links = p.links.clone();
            }
            save_profiles(&all);
        }
    }

    fn push(&self) {
        let tabs: Vec<Value> = self
            .tabs
            .iter()
            .map(|t| json!({"id": t.id, "title": t.title, "url": t.url, "start": t.view.is_none()}))
            .collect();
        let dls: Vec<Value> = self
            .downloads
            .iter()
            .rev()
            .map(|d| json!({"name": d.name, "state": d.state}))
            .collect();
        let links: Vec<Link> = self.profile.as_ref().map(|p| p.links.clone()).unwrap_or_default();
        let color = self
            .profile
            .as_ref()
            .map(|p| p.color.clone())
            .unwrap_or_else(|| "#ffffff".to_string());
        let st = json!({
            "tabs": tabs, "active": self.active, "downloads": dls,
            "profile": self.profile_name, "temp": self.temp,
            "links": links, "color": color, "version": VERSION
        });
        let _ = self.toolbar.evaluate_script(&format!("setState({})", st));
    }

    /// returns true when the app should exit
    fn on_event(&mut self, ev: UserEvent) -> bool {
        match ev {
            UserEvent::Ui(msg) => {
                let v: Value = serde_json::from_str(&msg).unwrap_or(Value::Null);
                match v["cmd"].as_str().unwrap_or("") {
                    "nav" => {
                        let u = normalize(v["url"].as_str().unwrap_or(""));
                        self.navigate(&u);
                    }
                    "back" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("history.back()"); }
                    }
                    "forward" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("history.forward()"); }
                    }
                    "reload" => {
                        if let Some(view) = self.active_view() { let _ = view.evaluate_script("location.reload()"); }
                    }
                    "home" => {
                        // Jump to the start page: reuse an existing one or open a new one.
                        let existing = self.tabs.iter().find(|t| t.view.is_none()).map(|t| t.id);
                        match existing {
                            Some(id) => {
                                self.active = id;
                                self.layout();
                                self.show_active();
                            }
                            None => self.open_tab(None),
                        }
                    }
                    "newtab" => self.open_tab(None),
                    "close" => {
                        if let Some(id) = v["id"].as_u64() {
                            if !self.close_tab(id as u32) {
                                return true;
                            }
                        }
                    }
                    "switch" => {
                        if let Some(id) = v["id"].as_u64() {
                            self.active = id as u32;
                            self.layout();
                            self.show_active();
                        }
                    }
                    "overlay" => {
                        self.panel = v["on"].as_bool().unwrap_or(false);
                        self.layout();
                        self.show_active();
                    }
                    "temp" => {
                        let u = normalize(v["url"].as_str().unwrap_or(""));
                        spawn_self(&["--temp", &u]);
                    }
                    "tempwin" => spawn_self(&["--temp"]),
                    "profiles" => spawn_self(&[]),
                    "addlink" => {
                        if let Some(url) = clean_link(v["url"].as_str().unwrap_or("")) {
                            let title = link_title(v["title"].as_str().unwrap_or(""), &url);
                            self.update_links(move |l| {
                                if l.len() < MAX_LINKS {
                                    l.push(Link { title, url });
                                }
                            });
                        }
                    }
                    "editlink" => {
                        if let (Some(i), Some(url)) = (v["i"].as_u64(), clean_link(v["url"].as_str().unwrap_or(""))) {
                            let title = link_title(v["title"].as_str().unwrap_or(""), &url);
                            self.update_links(move |l| {
                                if let Some(x) = l.get_mut(i as usize) {
                                    x.title = title;
                                    x.url = url;
                                }
                            });
                        }
                    }
                    "dellink" => {
                        if let Some(i) = v["i"].as_u64() {
                            self.update_links(move |l| {
                                if (i as usize) < l.len() {
                                    l.remove(i as usize);
                                }
                            });
                        }
                    }
                    _ => {}
                }
                self.push();
            }
            UserEvent::TabTitle(id, t) => {
                if let Some(tab) = self.tabs.iter_mut().find(|x| x.id == id) {
                    tab.title = t.clone();
                }
                if id == self.active {
                    self.window.set_title(&format!("{} - {}", t, APP));
                }
                self.push();
            }
            UserEvent::TabUrl(id, u) => {
                if let Some(tab) = self.tabs.iter_mut().find(|x| x.id == id) {
                    tab.url = u;
                }
                self.push();
            }
            UserEvent::NewTab(u) => {
                self.open_tab(Some(&u));
                self.push();
            }
            UserEvent::DlStart(key, name) => {
                self.downloads.push(Dl { key, name, state: 0 });
                self.push();
            }
            UserEvent::DlDone(key, ok) => {
                if let Some(d) = self.downloads.iter_mut().rev().find(|d| d.key == key && d.state == 0) {
                    d.state = if ok { 1 } else { 2 };
                }
                self.push();
            }
        }
        false
    }
}

fn run_browser(profile: Option<Profile>, temp: bool, start: Option<String>) {
    let el = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy = el.create_proxy();

    let profile_name = if temp {
        "Temp session".to_string()
    } else {
        profile.as_ref().map(|p| p.name.clone()).unwrap_or_default()
    };

    let window = WindowBuilder::new()
        .with_title(format!("{} - {}", profile_name, APP))
        .with_inner_size(WinSize::new(1280.0, 800.0))
        .with_min_inner_size(WinSize::new(640.0, 420.0))
        .with_window_icon(window_icon())
        .with_theme(Some(Theme::Dark))
        .build(&el)
        .unwrap();

    // Each profile has its own WebView2 data folder = separate cookies/logins/cache.
    let data_dir = if temp {
        std::env::temp_dir().join(format!("{}-temp-{}", APP, std::process::id()))
    } else {
        profile_dir(&profile.as_ref().unwrap().id)
    };
    let _ = fs::create_dir_all(&data_dir);
    let mut ctx = WebContext::new(Some(data_dir));

    let size = window.inner_size().to_logical::<f64>(window.scale_factor());
    let ui_proxy = proxy.clone();
    let toolbar = WebViewBuilder::new_with_web_context(&mut ctx)
        .with_html(include_str!("../ui/browser.html"))
        .with_background_color(BLACK)
        .with_bounds(rect(0.0, 0.0, size.width, TOOLBAR_H))
        .with_ipc_handler(move |req| {
            let _ = ui_proxy.send_event(UserEvent::Ui(req.body().to_string()));
        })
        .build_as_child(&window)
        .unwrap();

    let mut b = Browser {
        window,
        ctx,
        proxy,
        toolbar,
        tabs: Vec::new(),
        active: 0,
        next_id: 1,
        panel: false,
        downloads: Vec::new(),
        profile_name,
        profile,
        temp,
    };
    // A saved profile opens on its start page (with the quick links);
    // a temp window opens the given link, or the start page if none.
    b.open_tab(start.as_deref());
    b.push();

    el.run(move |event, _, flow| {
        *flow = ControlFlow::Wait;
        match event {
            Event::WindowEvent { event, .. } => match event {
                WindowEvent::CloseRequested => *flow = ControlFlow::Exit,
                WindowEvent::Resized(_) => b.layout(),
                _ => {}
            },
            Event::UserEvent(ev) => {
                if b.on_event(ev) {
                    *flow = ControlFlow::Exit;
                }
            }
            _ => {}
        }
    });
}
